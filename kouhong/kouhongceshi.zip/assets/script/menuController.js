// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
       kouHongFigure:cc.Node,
       rewardPanel:cc.Node,
       levelUpPanel:cc.Node,
       exchangePanel:cc.Node,
       tutorPanel:cc.Node,
       bagPanel:cc.Node,
       payPanel:cc.Node,
       friendHelp:cc.Node,
       howTo:cc.Node,
       randPanel:cc.Node,
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {
       this.kouHongFigureClass = this.kouHongFigure.getComponent('figurePanel');
       this.rewardPanelClass = this.rewardPanel.getComponent('dialogReward');
       this.levelUpPanelClass = this.levelUpPanel.getComponent('dialogLevelUp');
       this.exchangePanelClass = this.exchangePanel.getComponent('dialogExchange');
       this.tutorPanelClass = this.tutorPanel.getComponent('tutorPanel');
       this.bagPanelClass = this.bagPanel.getComponent('dialogBag');
       this.payPanelClass = this.payPanel.getComponent('payDialog');
       this.friendHelpClass = this.friendHelp.getComponent('friendHelp');
       this.howToClass = this.howTo.getComponent('howTo');
       this.randList = this.randPanel.getComponent('randList');
       
       if(!cc.sys.localStorage.getItem("hasKey")){     
        this.tutorPanelClass.show();
        cc.sys.localStorage.setItem("hasKey",true); 
       }
    },

    onEnable(){
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP, this.onKeyUp, this);
        cc.app.dispatcher.on(cc.app.Cmd.CMD_APP_SHOW_LEVEL_UP_PANEL,this.onShowLevelUp,this);
        cc.app.dispatcher.on(cc.app.Cmd.CMD_APP_SHOW_REWARD_PANEL,this.onShowReward,this);
        cc.app.dispatcher.on(cc.app.Cmd.CMD_APP_ON_SHOW_FUSION37_38,this.onShowFusion37,this);
        
        jsBridge.onClose(function(appData){
            
            if( cc.app.mconfig.getIsMainPage()){
                cc.app.mconfig.backCount --;
                if(cc.app.mconfig.backCount>0){
                    setTimeout(function(){
                        cc.app.mconfig.backCount = 2;
                    },2000);
                    jsBridge.toast("再次按返回键退出App");
                    return false;
                }
                return true;
            }else{
                cc.app.dispatcher.emit(cc.app.Cmd.CMD_APP_KEY_BACK,"");
                return false;
            }
        });
    },

    onDisable(){
        cc.systemEvent.off(cc.SystemEvent.EventType.KEY_UP, this.onKeyUp);
        cc.app.dispatcher.off(cc.app.Cmd.CMD_APP_SHOW_LEVEL_UP_PANEL,this.onShowLevelUp);
        cc.app.dispatcher.off(cc.app.Cmd.CMD_APP_SHOW_REWARD_PANEL,this.onShowReward);
        cc.app.dispatcher.off(cc.app.Cmd.CMD_APP_ON_SHOW_FUSION37_38,this.onShowFusion37);
    },

    onKeyUp(event){
        switch(event.keyCode) {
            case cc.macro.back:
                cc.app.dispatcher.emit(cc.app.Cmd.CMD_APP_KEY_BACK);
                break;
        }
    },
    onClickPlayFullAdd(){
        //全屏视频
        jsBridge.ttAd.fullScreenVideoAd({
            //字符串类型，广告代码位ID
            codeId         : "945123869",
            //布尔类型，是否支持深度链接
            supportDeepLink: true,
            //数字类型，期望的宽度
            acceptedWidth  : 750,
            //数字类型，期望的高度
            acceptedHeight : 1334,
            userId         : "user123321",
            //字符串类型，期望视频播放的方向
            //HORIZONTAL 水平
            //VERTICAL   垂直
            orientation    : "VERTICAL"
        }, function(succ, data) {
            jsBridge.toast('.广告触发状态:'+succ+"  dataa:"+data);
        });
    },

    onShowFusion37(data){
       this.randList.show(data);
    },
    onShowLevelUp(data){
       this.levelUpPanelClass.show(data);
    },

    onShowReward(data){
        this.rewardPanelClass.show(data);
    },

    onClickBuy(){
        cc.app.controller.reqBuy();
       
    },

    onClickChuangGuan(){
        jsBridge.open({
            url:"http://test.treemay.com/app/./index.php?i=2&c=entry&eid=25",
            showTitle:true
        });
       // location= "http://test.treemay.com/app/./index.php?i=2&c=entry&eid=25";
        cc.app.network.close();
    },

    onClickXinYuanLiHe(){
        jsBridge.open({
            url:"http://test.treemay.com/app/./index.php?i=2&c=entry&eid=51",
            showTitle:true
        });
        //location = "http://test.treemay.com/app/./index.php?i=2&c=entry&eid=51";
        cc.app.network.close();
    },

    onClickKouHongNvShen(){
        
    },
    onClickMineInfo(){
        jsBridge.open({
            url:"http://test.treemay.com/app/./index.php?i=2&c=entry&eid=26",
            showTitle:true
        });
       // location = "http://test.treemay.com/app/./index.php?i=2&c=entry&eid=26";
        cc.app.network.close();
    },

    onClickKouHong(){
        this.kouHongFigureClass.show();
    },

    onClickBaoBao(){
        this.bagPanelClass.show();
    },

    onClickFriendHelp(){
        this.friendHelpClass.show();
    },

    onClickCash(){
        this.payPanelClass.show();
    },

    onClickTutor(){
        this.howToClass.show();
    },

    onClickKouHongJingLing(){
        this.exchangePanelClass.show();
    },



    // update (dt) {},
});
