var httpRequest = {
   openUrl(url,type,cb){
      let that = this;  
      this.xhr = cc.loader.getXMLHttpRequest();
      this.xhr.timeout = 5000;// 5 seconds for timeout
    
      this.xhr.onreadystatechange = function(){
         if (that.xhr.readyState === 4 && (that.xhr.status >= 200 && that.xhr.status < 300)) {
            var respone =that.xhr.responseText;
            cb(respone);
         }
      };
     
      this.xhr.open(type, url, true);
      this.xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");  
      this.xhr.send();
   },

   // note: In Internet Explorer, the timeout property may be set only after calling the open()
   // method and before calling the send() method.
};

module.exports= httpRequest;
