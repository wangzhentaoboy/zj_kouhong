// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
       remain:cc.Label,
       panel:cc.Node,
       btn_play:cc.Button,
       bonus:cc.Label,
       btnTxt:cc.Label,
    },

    start () {

    },

    onClickPlayRewardVedio(){
      //激励视频
      let that = this;
      let curt = new Date().getTime();
      let pre = cc.sys.localStorage.getItem("lastTime")||0;
      let pastTime = (curt-pre)/1000;
      if(pastTime<60) return  jsBridge.toast("请过"+(60-pastTime)+"秒后再试");
      cc.sys.localStorage.setItem("lastTime",curt);

      jsBridge.ttAd.rewardVideoAd({
      //字符串类型，广告代码位ID
      codeId         : "945123869",
      //布尔类型，是否支持深度链接
      supportDeepLink: false,
      //数字类型，期望的宽度
      acceptedWidth  : 750,
      //数字类型，期望的高度
      acceptedHeight : 1334,
      //字符串类型，期望视频播放的方向
      //HORIZONTAL 水平
      //VERTICAL   垂直
      orientation    : "VERTICAL",

      //数字类型，广告数量
      adCount        : 1,
      // //字符串类型，激励奖品名称
      // rewardName     : "金币",
      // //数字类型，激励奖品数量
      rewardAmount   : 5,
      //字符串类型，用户ID
      userId         : cc.sys.localStorage.getItem("uid"),
      //字符串类型，附件信息
      mediaExtra     : "激励视频"
      }, 
      function(succ, data) {
         jsBridge.toast('.广告触发状态:'+succ+"  dataa:"+data);
         cc.app.dispatcher.emit(cc.app.Cmd.CMD_APP_UPDATE_USERINFO,"");
         console.log('.......广告触发状态.....广告触发状态....回调...........................');
      });

      that.onClickClose();
      
    },

    show(data){
       this.node.active = true;
       this.panel.scale = 0.3;
       this.remain.string = data.leftVideoTimes;
       this.panel.runAction(cc.sequence(cc.scaleTo(0.15,1.1),cc.scaleTo(0.1,1))); 
       if(data.leftVideoTimes<=0){
          this.btn_play.interactable = false;
       }else{
         this.btn_play.interactable = true;
       }
       let maxlv = cc.app.mconfig.getKhMaxLv();
       let rlv = cc.app.mconfig.kouHongPath[Math.max(0,maxlv-1)].buyLv;
       if(rlv>=14&&rlv<=25){
           this.btnTxt.string = "立即获得3小时收益"
       }else{
           this.btnTxt.string = "立即获得2小时收益"
       }
       let that = this;
       let uid  = cc.sys.localStorage.getItem('uid');
       cc.app.http.openUrl("http://game.treemay.com/index.php/index/api/twoHours?userid="+uid,"GET",function(res){
             let data = JSON.parse(res);
             that.bonus.string =cc.app.mconfig.formatNumber(data.data) ;
       });
    },

    onClickClose(){
       this.panel.runAction(cc.sequence(cc.scaleTo(0.2,0),cc.callFunc(function(){
           this.node.active= false;
       }.bind(this))));  
    },

    // update (dt) {},
});
